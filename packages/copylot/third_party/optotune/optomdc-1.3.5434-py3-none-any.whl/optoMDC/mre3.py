from ._connections import Board as _Board, Channel as _Channel
from .registers import mre2_registers as mre2Registers
from .registers import mre3_registers as mre3Registers
from .tools.list_comports import get_ftdi_port
from .tools.definitions import MRE2_CHANNEL_CNT
"""MR-E-3 SDK.

The MR-E-3 SDK is organized in the following way:

         Board.Channel.System.RegisterCommand(parameters)

  Board:      Low/mid level object for operating the firmware (vector patterns, simple/pro commands, etc)
  Channel:    A given channel, which can set input types, gain, etc.
  System:     Each channel has its own stages. From here can perform commands that get/set individual registers.
  registers:  Each system has several registers, which are dictionaries with elements regarding valid units/range.


To begin:
Import necessary module and initialize a board (verbose for console output)

>>>import optoMDC
>>>mre3 = optoMDC.connect4(port='COM12')  # this will connect and synchronize all channel with the firmware

Define the system you want to interact with (board.mirror.channel.system) (see registers.system_names for a list)
>>>sig_gen = mre3.Mirror.Channel_0.SignalGenerator
Start setting individual registers
>>>sig_gen.SetAmplitude(0.1)

Additional operations are available directly through the Board object (get/set multiple, reset, etc)
For example, multiple set/get can be done. After this, the system will output a sinusoid on channel 0.
>>>mre3.set_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run], [10.0, 0.1, Units.CURRENT, 1])
>>>mre3.get_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run])

Example
-------
More examples to come...
"""


# standard MR-E-3 Board
class MRE3Board(_Board):
    r"""
        Board object from which to issue MR-E-3 commands over a serial connection.

        Parameters
        ----------
        port, baud rate, comm_lock, verbose
        Standard serial connection parameters. Extended from Connection class.
        Raises
        ------
        none

        Notes
        -----
        Board extends Connection class. Refer to Connection for methods, parameters, etc.
        Board inherits Commands. Refer to Commands for methods, parameters, etc.
    """
    def __init__(self, port: str or None = None, verbose: bool = False):
        if port is None:
            try:
                port = get_ftdi_port()
            except IndexError:
                print("MR-E-3 Device Not Found. Check Connection.")
        _Board.__init__(self, port=port, verbose=verbose)
        # board-level systems
        # => \link optoMDC.registers.mre3_registers.MRE3Status MRE3Status\end link
        self.Status = mre3Registers.MRE3Status(board=self)
        # => \link optoMDC.registers.mre3_registers.MRE3TemperatureManager MRE3TemperatureManager\end link
        self.TemperatureManager = mre3Registers.MRE3TemperatureManager(board=self)
        # => \link optoMDC.registers.mre3_registers.MRE3MiscFeatures MRE3MiscFeatures\end link
        self.MiscFeatures = mre3Registers.MRE3MiscFeatures(board=self)
        # => \link optoKummenberg.registers.MiscSystems.Logger Logger\end link
        self.Logger = mre3Registers.Logger(board=self)
        # => \link optoKummenberg.registers.MiscSystems.SnapshotManager SnapshotManager\end link
        self.SnapshotManager = mre3Registers.SnapshotManager(board=self)
        # => \link optoMDC.registers.mre2_registers.ResonantAmplitudeControl ResonantAmplitudeControl\end link
        self.ResonantAmplitudeControl = mre2Registers.ResonantAmplitudeControl(board=self)

        # channel-level systems
        # => \link optoMDC.mre3.MRE3Channel MRE3Channel\end link
        self.Channel_0 = MRE3Channel(self, 0)
        # => \link optoMDC.mre3.MRE3Channel MRE3Channel\end link
        self.Channel_1 = MRE3Channel(self, 1)
        # all available channels array of type
        # => \link optoMDC.mre3.MRE3Channel MRE3Channel\end link
        self.channel = [self.Channel_0, self.Channel_1]

        # => \link optoMDC.registers.mre3_registers.MRE3BoardEEPROM MRE3BoardEEPROM\end link
        self.EEPROM = mre3Registers.MRE3BoardEEPROM(board=self)

        self.OpticalFeedback = mre3Registers.OpticalFeedback(board=self)
        # => \link optoKummenberg.registers.SignalFlowManager.SignalFlowManager SignalFlowManager\end link
        self.SignalFlowManager = mre3Registers.SignalFlowManager(board=self)
        # => \link optoKummenberg.registers.MiscSystems.VectorPatternMemory VectorPatternMemory\end link
        self.VectorPatternMemory = mre3Registers.VectorPatternMemory(board=self)
        # => \link optoKummenberg.registers.MiscSystems.ADCcontrol ADCcontrol\end link
        self.ADCcontrol = mre3Registers.ADCcontrol(board=self)
        # => \link optoKummenberg.registers.MiscSystems.DACcontrol DACcontrol\end link
        self.DACcontrol = mre3Registers.DACcontrol(board=self)
        # => \link optoMDC.registers.mre3_registers.RadialBasisFunction RadialBasisFunction\end link
        self.RadialBasisFunction = mre3Registers.RadialBasisFunction(board=self)

        # => \link optoKummenberg.registers.ControlStage.CurrentFeedThrough CurrentFeedThrough\end link
        self.CurrentFeedThrough = mre2Registers.CurrentFeedThrough(board=self)
        # => \link optoKummenberg.registers.OutputStage.LinearOutput LinearOutput\end link (sysid=0xE8)
        self.LinearOutput = mre3Registers.LinearOutput(board=self)
        # => \link optoKummenberg.registers.InputStage.SignalFlowFeedback SignalFlowFeedback\end link
        self.SignalFlowFeedback = mre3Registers.SignalFlowFeedback(self.SignalFlowManager)

        self.systems = mre3Registers.systems()

        if self.verbose:
            print('Initialization Finalized. Board is Ready.')


# Parent class => \link optoKummenberg.connections.Channel Channel\end link <br>
class MRE3Channel(_Channel):
    r"""
        Class to control single channel of the MR-E-3 driver. It contains systems supported on specific channel.
    """
    def __init__(self, board, channel_number: int = 0):
        _Channel.__init__(self, board, channel_number)
        self.StaticInput = mre3Registers.MRE3StaticInput(self._channel, self._board)
        # => \link optoKummenberg.registers.MiscFeatures.DeviceEEPROM DeviceEEPROM\end link
        self.DeviceEEPROM = mre3Registers.DeviceEEPROM(self._channel, self._board)
        # => \link optoKummenberg.registers.AnalogInput AnalogInput\end link
        self.Analog = mre2Registers.Analog(self._channel, self._board)
        # => \link optoKummenberg.registers.InputStage.SignalGenerator SignalGenerator\end link
        self.SignalGenerator = mre2Registers.SignalGenerator(self._channel, self._board)
        # => \link optoKummenberg.registers.InputStage.VectorPatternUnit VectorPatternUnit\end link
        self.VectorPatternUnit = mre3Registers.VectorPatternUnit(self._channel, self._board)
        # => \link optoKummenberg.registers.InputConditioning.InputConditioningFilter InputConditioningFilter\end link
        self.InputConditioningFilter = mre3Registers.InputConditioningFilter(self._channel, self._board)
        # => \link optoKummenberg.registers.OutputConditioning.OutputConditioningFilter OutputConditioningFilter\end lin
        self.OutputConditioningFilter = mre3Registers.OutputConditioningFilter(self._channel, self._board)
        # => \link optoMDC.registers.mre3_registers.OFPID OFPID\end link
        self.OFPID = mre3Registers.OFPID(self._channel, self._board)
        # => \link optoMDC.registers.mre3_registers.XYPID XYPID\end link
        self.XYPID = mre3Registers.XYPID(self._channel, self._board)
        # => \link optoKummenberg.registers.InputStage.QuadrantVectorPatternUnit QuadrantVectorPatternUnit\end link
        self.QuadrantVectorPatternUnit = mre3Registers.QuadrantVectorPatternUnit(self._channel, self._board)
        