r"""
Lookup tables / management of System registers specific to the MR-E-3.

Each System is represented by its own class, with Registers as attributes of that class.
The registers module can be imported to retrieve information about a given registers.
Syntax is as follows: registers.SYSTEM_NAME(CHANNEL_NUMBER).REGISTER_NAME

Returns
-------
dict
    A standard lookup will return a Register Record, or dictionary, containing pertinent registers information.

Notes
-----
A handful of helper methods are included to manage registers requests. See corresponding info for the following:
    is_valid_channel(value), is_valid_value(register_dict, value)
    tools.parsing_tools.encode(command_id, register_id)
    system_info()
    system_names()
    register_names(system_name)
    tools.systems_registers_tools.get_register(system_name, register_name, channel)
    parse_error(error_code)
    help()

Examples
--------

For example, this imports the registers module, and collects the registers record of USB channel 0, as well as the
registers record for setting the input channel system of the Signal Flow Manager.

    >>> from optoICC import registers
    >>> registers.StaticInput(0).of
    >>> registers.StaticInput(0).of
    {'id': 20737, 'type': <class 'float'>, 'unit': None, 'range': [-1, 1], 'default': 0.0}
    >>> registers.Manager(0).input
    {'id': 16384, 'type': <class 'int'>, 'unit': 'SystemID', 'range': None, 'default': None}
    >>> from optoICC.tools.systems_registers_tools import is_valid_value
    >>> is_valid_value(registers.StaticInput(0).xy, 0.8)
    True

Additional Notes
----------------
For more info on a given registers, see the help text in the corresponding System class.
This will display ID, Data Type, Units, Range, Default Value, and Comments.
    >>> registers.SignalGenerator.help()

For a complete list of registers for a given system, call one of the helper methods from registers module itself.
    >>> registers.get_registers(system_name='StaticInput', channel=1)


"""
from optoKummenberg.registers.generic_registers import *
from optoKummenberg.tools.definitions import DeviceModel
from ..tools.definitions import MRE3_PHOTO_DIODES_CNT
from ..tools.parsing_tools import parse_error_flags_mre3


class MRE3Status(Status):
    r"""
 * Register map:
 *
 * Address | Name                  | Default      | Description                                     | Format and value        | Access     |
 * --------|-----------------------|--------------|-------------------------------------------------|-------------------------|------------|
 * 0x1000  |FW Id                  |              |                                                 | uint32                  | read only  |
 * 0x1001  |FW Branch              |              |                                                 | uint32                  | read only  |
 * 0x1002  |FW Type                |              |                                                 | uint32                  | read only  |
 * 0x1003  |FW Version Major       |              |                                                 | uint32                  | read only  |
 * 0x1004  |FW Version Minor       |              |                                                 | uint32                  | read only  |
 * 0x1005  |FW Version Build       |              |                                                 | uint32                  | read only  |
 * 0x1006  |FW Version Revision    |              |                                                 | uint32                  | read only  |
 * 0x1007  |System status errors   | 0 - No error | Register encodes system status and errors       | Read:<br/>   Bit#<br/>0 - Channel 0 output fault condition<br/>1 - Channel 0 output had fault condition<br/>2 - Channel 1 output fault condition<br/>3 - Channel 1 output had fault condition<br/>4 - Channel 2 output fault condition<br/>5 - Channel 2 output had fault condition<br/>6 - Channel 3 output fault condition<br/>7 - Channel 3 output had fault condition<br/>8 - Driver over-heat fault<br/>9 - Driver had over-heat fault<br/>10 - Device on channel 0 not detected<br/>11 - Device on channel 0 was not detected<br/>12 - Device on channel 1 not detected<br/>13 - Device on channel 1 was not detected<br/>14 - Device on channel 2 not detected<br/>15 - Device on channel 2 was not detected<br/>16 - Device on channel 3 not detected<br/>17 - Device on channel 3 was not detected<br/>18 - Channel 0 has over-current fault on 3V3 supply line<br/>19 - Channel 0 had over-current fault on 3V3 supply line<br/>20 - Channel 1 has over-current fault on 3V3 supply line<br/>21 - Channel 1 had over-current fault on 3V3 supply line<br/>22 - Channel 2 has over-current fault on 3V3 supply line<br/>23 - Channel 2 had over-current fault on 3V3 supply line<br/>24 - Channel 3 has over-current fault on 3V3 supply line<br/>25 - Channel 3 had over-current fault on 3V3 supply line<br/>26-31 - Reserved<br/>Write:<br/> Writing to this register resets all history error flags (odd bits 1, 3, .. 25)<br/> | read write |
 * 0x1008  |Dev.EEPROM active chan.| 0 = channel 0| Register switches I2C bus among channels        | uint32                  | read write |
 * 0x1009  |Dev.detect switch mask | 0            | SW switch parallel to Dev.Det.switches          | uint32                  | read write |
 * 0x100a  |DEV_TYPE0              | 0            | get device type on channel 0                    | uint32                  | read only  |
 * 0x100b  |DEV_TYPE1              | 0            | get device type on channel 1                    | uint32                  | read only  |
 * 0x100c  |NOT USED
 * 0x100d  |NOT USED
 * 0x100e  |MCU ID                 | 0            | get MCU type identification number              | uint32                  | read only  |
 * 0x100f  |MCU load               | 0            | get Signal Flow execution load in %             | uint32                  | read only  |
 * 0x1010  |MCU overload counter   | 0            | increments if Signal Flow execution load > 95%  | uint32                  | read only  |
 *
 *
 *
 * Vector map (vectors have their own address space):
 * Address | Name           | Default  | Description | Format and value | Access    |
 * --------|----------------|----------|-------------|------------------|-----------|
 * 0x1000  |Firmware SN     |          |             | ascii string     | read only |
 * 0x1001  |Git HEAD SHA1   |          |             | ascii string     | read only |
 * 0x1002  |MCU type string |          |             | ascii string     | read only |
 *
 *
    """

    @staticmethod
    def help():
        print(Status.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        Status.__init__(self, board=board)

        self.device_status = {'id': self.sys_id << 8 | 0x07,
                              'type': int,
                              'unit': None,
                              'range': None,
                              'default': None,
                              'value': None}
        self.device_eeprom_active_channel = {'id': self.sys_id << 8 | 0x08,
                                             'type': int,
                                             'unit': None,
                                             'range': None,
                                             'default': None,
                                             'value': None}
        self.device_detect_switch_mask = {'id': self.sys_id << 8 | 0x09,
                                          'type': int,
                                          'unit': None,
                                          'range': None,
                                          'default': None,
                                          'value': None}
        self.device_type_chan0 = {'id': self.sys_id << 8 | 0x0a,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': None,
                                  'value': None}
        self.device_type_chan1 = {'id': self.sys_id << 8 | 0x0b,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': None,
                                  'value': None}
        self.mcu_id = {'id': self.sys_id << 8 | 0x0e,
                       'type': int,
                       'unit': None,
                       'range': None,
                       'default': None,
                       'value': None}

        self.mcu_load = {'id': self.sys_id << 8 | 0x0f,
                         'type': float,
                         'unit': None,
                         'range': None,
                         'default': None,
                         'value': None}

        self.mcu_overload_counter = {'id': self.sys_id << 8 | 0x10,
                                     'type': int,
                                     'unit': None,
                                     'range': None,
                                     'default': None,
                                     'value': None}

        self.mcu_type = {'id': self.sys_id << 8 | 0x02, 'type': str}

        self.name = self.__class__.__name__

    # Gets the number of the EEPROM active channel. When reading device EEPROM, data is read from this channel.
    def GetDeviceEEPROMactiveChannel(self):
        return self.get_register('device_eeprom_active_channel')

    # Sets the number of the EEPROM active channel. When reading device EEPROM data is read from this channel.
    def SetDeviceEEPROMactiveChannel(self, channel):
        return self.set_register('device_eeprom_active_channel', channel)

    ## Register encodes system status and errors.
    def GetDeviceStatus(self):
        return self.get_register('device_status')

    def GetDeviceID(self, channel) -> DeviceModel:
        reg = self.get_register('device_type_chan0')
        return DeviceModel(reg)

    # Parses status register value based on active bits which are corresponding to the individual errors.
    # This method is used inside of the method GetErrorFlagRegister
    def parse_error_flags(self, error_flag_data: int):
        return parse_error_flags_mre3(error_flag_data)

    # Gets the value of the device detect switch. SW switch parallel to Device Detect switches.
    # (bit 0 => Channel 0, bit 1 => Channel 1,...)
    def GetDeviceDetectSwitchMask(self):
        return self.get_register('device_detect_switch_mask')

    # Sets the value of the device detect switch. SW switch parallel to Device Detect switches.
    # (bit 0 => Channel 0, bit 1 => Channel 1,...)
    def SetDeviceDetectSwitchMask(self, mask):
        return self.set_register('device_detect_switch_mask', mask)

    # Gets MCU type identification number
    def GetMCUid(self):
        return self.get_register('mcu_id')

    # Gets MCU type string
    def GetMCUtype(self, index, count):
        return self._board.get_vector(self.mcu_type, index, count)

    # Gets the Signal Flow execution load in %
    def GetMCUload(self):
        return self.get_register('mcu_load')

    # Counter that increments if Signal Flow execution load > 95%. This register resets after reading.
    def GetMCUoverloadCounter(self):
        return self.get_register('mcu_overload_counter')


# control mode
class OFPID(ControlStage):
    r"""
Control Mode Channel - OF PID Control (with/without Temperature Compensation)
System ID: 0xB8 through 0xBf

+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Register Name      | Id   | Type        | Unit | Range | Default | Comment                                          |
+====================+======+=============+======+=======+=========+==================================================+
| inverted_out       | 0x00 |boolean      |None  |       |   0     | Defines whether PID output is inverted (* -1) or not|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kp                 | 0x01 |float 32-bit |None  |       |   10.0  |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ki                 | 0x02 |float 32-bit |None  |       |   200.0 |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kd                 | 0x03 |float 32-bit |None  |       |   0.04  |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_output         | 0x04 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_output         | 0x05 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_integral       | 0x06 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_integral       | 0x07 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Enable filter      | 0x13 |boolean      |None  |       | true    | Enables / disables filter on derivate term       |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Cutoff frequency   | 0x14 |float 32-bit |None  |       | 800.0   | Sets cut-off frequency in Hz                     |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| PID system output  | 0x17 |float 32-bit |None  |       | 0       | Actual output value at PID output                |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Position Stability Limit Channel 0-1  | 0x19   |float 32-bit     |None  |       | 0.05       | Maximum allowable position error on channel for Mirror stable state.                |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Position Error Channel 0-1            | 0x1A |float 32-bit |None  |       | 0       | Actual position error on channel               |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Velocity Stability Limit Channel 0-1  | 0x1B |float 32-bit |None  |       | 2.0       | Maximum allowable velocity on channel for Mirror stable state                |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Velocity (OF Time Derivative) Channel 0-1  | 0x1C |float 32-bit |None  |       | 0       | Actual velocity on channel, Feedback signal time derivative. Used for mirror stable condition                |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
    """

    @staticmethod
    def help():
        print(OFPID.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xB8 | channel
        self._readonly = False

        self.inverted_out = {'id': self.sys_id << 8 | 0x00,
                   'type': bool,
                   'unit': None,
                   'range': None,
                   'default': 0,
                   'value': 0}

        self.kp = {'id': self.sys_id << 8 | 0x01,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 10.0,
                   'value': 10.0}
        self.ki = {'id': self.sys_id << 8 | 0x02,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 200.0,
                   'value': 200.0}
        self.kd = {'id': self.sys_id << 8 | 0x03,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 0.04,
                   'value': 0.04}
        self.min_output = {'id': self.sys_id << 8 | 0x04,
                           'type': float,
                           'unit': None,
                           'range': None,
                           'default': -1.0,
                           'value': -1.0}
        self.max_output = {'id': self.sys_id << 8 | 0x05,
                           'type': float,
                           'unit': None,
                           'range': None,
                           'default': 1.0,
                           'value': 1.0}
        self.min_integral = {'id': self.sys_id << 8 | 0x06,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': -1.701411735e+38,
                             'value': 0}
        self.max_integral = {'id': self.sys_id << 8 | 0x07,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': 1.701411735e+38,
                             'value': 0}
        self.enable_filter = {'id': self.sys_id << 8 | 0x13,
                              'type': bool,
                              'unit': None,
                              'range': None,
                              'default': True,
                              'value': True}
        self.cutoff_frequency = {'id': self.sys_id << 8 | 0x14,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 800.0,
                                 'value': 800.0}
        self.position_limit = {'id': self.sys_id << 8 | 0x19,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 0.05,
                                 'value': 0.05}
        self.position_error = {'id': self.sys_id << 8 | 0x1A,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 0.0,
                                 'value': 0.0}
        self.velocity_limit = {'id': self.sys_id << 8 | 0x1B,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 2.0,
                                 'value': 2.0}
        self.velocity = {'id': self.sys_id << 8 | 0x1C,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 0.0,
                                 'value': 0.0}

        ControlStage.__init__(self, channel, board)
        self.name = self.__class__.__name__

    def GetPositionLimit(self):
        return self.get_register('position_limit')

    def SetPositionLimit(self, value):
        return self.set_register('position_limit', value)

    def GetVelocityLimit(self):
        return self.get_register('velocity_limit')

    def SetVelocityLimit(self, value):
        return self.set_register('velocity_limit', value)


class XYPID(ControlStage):
    r"""
Control Mode Channel -  PID 2 Control (with/without Temperature Compensation)
System ID: 0xC0 through 0xC3

+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Register Name      | Id   | Type        | Unit | Range | Default | Comment                                          |
+====================+======+=============+======+=======+=========+==================================================+
| inverted_out       | 0x00 |boolean      |None  |       |   0     | Defines whether PID output is inverted (* -1) or not|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kp                 | 0x01 |float 32-bit |None  |       |  15.0   |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ki                 | 0x02 |float 32-bit |None  |       |  200.0  |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kd                 | 0x03 |float 32-bit |None  |       | 0.05    |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_output         | 0x04 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_output         | 0x05 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_integral       | 0x06 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_integral       | 0x07 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Enable filter      | 0x13 |boolean      |None  |       | true    | Enables / disables filter on derivate term       |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Cutoff frequency   | 0x14 |float 32-bit |Hz    |       | 800.0   | Sets cut-off frequency in Hz                     |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Position Stability Limit Channel 0-1  | 0x19   |float 32-bit     |None  |       | 0.05       | Maximum allowable position error on channel for Mirror stable state.                |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Position Error Channel 0-1            | 0x1A |float 32-bit |None  |       | 0       | Actual position error on channel               |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Velocity Stability Limit Channel 0-1  | 0x1B |float 32-bit |None  |       | 4.0       | Maximum allowable velocity on channel for Mirror stable state                |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Velocity (OF Time Derivative) Channel 0-1  | 0x1C |float 32-bit |None  |       | 0       | Actual velocity on channel, Feedback signal time derivative. Used for mirror stable condition                |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
    """

    @staticmethod
    def help():
        print(XYPID.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xC0 | channel
        self._readonly = False

        self.inverted_out = {'id': self.sys_id << 8 | 0x00,
                   'type': bool,
                   'unit': None,
                   'range': None,
                   'default': 0,
                   'value': 0}

        self.kp = {'id': self.sys_id << 8 | 0x01,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 15.0,
                   'value': 15.0}
        self.ki = {'id': self.sys_id << 8 | 0x02,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 200.0,
                   'value': 200.0}
        self.kd = {'id': self.sys_id << 8 | 0x03,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 0.05,
                   'value': 0.05}
        self.min_output = {'id': self.sys_id << 8 | 0x04,
                           'type': float,
                           'unit': None,
                           'range': None,
                           'default': -1.0,
                           'value': -1.0}
        self.max_output = {'id': self.sys_id << 8 | 0x05,
                           'type': float,
                           'unit': None,
                           'range': None,
                           'default': 1.0,
                           'value': 1.0}
        self.min_integral = {'id': self.sys_id << 8 | 0x06,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': -1.701411735e+38,
                             'value': 0}
        self.max_integral = {'id': self.sys_id << 8 | 0x07,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': 1.701411735e+38,
                             'value': 0}
        self.enable_filter = {'id': self.sys_id << 8 | 0x13,
                              'type': bool,
                              'unit': None,
                              'range': None,
                              'default': True,
                              'value': True}
        self.cutoff_frequency = {'id': self.sys_id << 8 | 0x14,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 800.0,
                                 'value': 800.0}
        self.position_limit = {'id': self.sys_id << 8 | 0x19,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 0.05,
                                 'value': 0.05}
        self.position_error = {'id': self.sys_id << 8 | 0x1A,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 0.0,
                                 'value': 0.0}
        self.velocity_limit = {'id': self.sys_id << 8 | 0x1B,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 4.0,
                                 'value': 4.0}
        self.velocity = {'id': self.sys_id << 8 | 0x1C,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 0.0,
                                 'value': 0.0}

        ControlStage.__init__(self, channel, board)
        self.name = self.__class__.__name__

    def GetPositionLimit(self):
        return self.get_register('position_limit')

    def SetPositionLimit(self, value):
        return self.set_register('position_limit', value)

    def GetVelocityLimit(self):
        return self.get_register('velocity_limit')

    def SetVelocityLimit(self, value):
        return self.set_register('velocity_limit', value)

class MRE3MiscFeatures(System):
    """
/**
 * page MiscFeatures Miscellaneous Features
 *
 * Miscellaneous Features system ID : <b>0x25</b>
 *
 * ## Register Map:
 *
 *  | Address | Name                             | Default Value | Description                                                      | Type   |  Access    |
 *  | --------|----------------------------------|---------------|------------------------------------------------------------------|------- | -----------|
 *  | 0x2500  | Reset firmware                   | N/A           | Reading triggers function                                        | uint32 | read only  |
 *  | 0x2501  | FrontEnd power state             | false=0       | Setting of FrontEnd power supply state                           | boolean| read write |
 *  | 0x2502  | FrontEnd voltage                 | 18.0          | Setting of FrontEnd supply voltage [V]                           | float  | read write |
 *  | 0x2503  | Output stage PWM frequency       | 1000          | Setting of PWM frequency [400, 500, 600, 1000 and 1200 kHz]      | uint32 | read write |
 *  | 0x2504  | Enable output stage channel 0    | false=0       | Setting of output stage state channel 0                          | boolean| read write |
 *  | 0x2505  | Enable output stage channel 1    | false=0       | Setting of output stage state channel 1                          | boolean| read write |
 *  | 0x2506  | NOT USED
 *  | 0x2507  | NOT USED
 *  | 0x2508  | ADCI0						     | N/A	         | Reading of current on channel 0                                  | float  | read only  |
 *  | 0x2509  | ADCI1						     | N/A	         | Reading of current on channel 1                                  | float  | read only  |
 *  | 0x250a  | NOT USED
 *  | 0x250b  | NOT USED
 *  | 0x250c  | ADCV0						     | N/A	         | Reading of voltage on channel 0                                  | float  | read only  |
 *  | 0x250d  | ADCV1						     | N/A	         | Reading of voltage on channel 1                                  | float  | read only  |
 *  | 0x250e  | NOT USED
 *  | 0x250f  | NOT USED
 *  | 0x2510  | DEV_POWER0					     | 0	         | Setting 3v3 for device on channel 0                              | uint32 | read write |
 *  | 0x2511  | DEV_POWER1					     | 0	         | Setting 3v3 for device on channel 1                              | uint32 | read write |
 *  | 0x2512  | NOT USED
 *  | 0x2513  | NOT USED
 *  | 0x2514  | DEV_MODEL0					     | 0	         | get \ref DeviceModel on channel 0                                | uint32 | read only  |
 *  | 0x2515  | DEV_MODEL1					     | 0	         | get \ref DeviceModel on channel 1                                | uint32 | read only  |
 *  | 0x2516  | NOT USED
 *  | 0x2517  | NOT USED
 *  | 0x2518  | Uin							     | N/A	         | Reading input voltage		                                    | float  | read only  |
 *  | 0x2519  | Iin							     | N/A	         | Reading input current		                                    | float  | read only  |
 *  | 0x251a  | Ufe							     | N/A	         | Reading FE voltage			                                    | float  | read only  |
 *  | 0x251b  | ANLGIN0						     | N/A	         | Reading of analog input channel 0                                | float  | read only  |
 *  | 0x251c  | ANLGIN1						     | N/A	         | Reading of analog input channel 1                                | float  | read only  |
 *  | 0x251d  | NOT USED
 *  | 0x251e  | NOT USED
 *  | 0x251f  | AUTO_CONFIG     			     | 0	         | Configures both channels of driver into specific mode: 0 - Open loop, 1 - Close loop Optical Feedback, 2 - Close loop XY, 3 - Resonant mirror mode (not applied yet) | uint32 | read write |
 *  | 0x2520  | WRITE_CTRL                       | 0             | Reading returns WC state, writing sets state of WC output signal | uint32 | read write |
 *  | 0x2521  | LOAD_CH0                         | 0	         | Reading load resistance on channel 0 (set some DC current before)| float  | read only  |
 *  | 0x2522  | LOAD_CH1                         | 0	         | Reading load resistance on channel 1 (set some DC current before)| float  | read only  |
 *  | 0x2523  | NOT USED
 *  | 0x2524  | NOT USED
 *  | 0x2525  | Enable calibration coefficients  | true=1 *(1)   | Enable calibration coefficients for measurements in this system  | boolean| read write |
 *  | 0x2526  | SET_STATE         			     | -	         | 1 set driver to init state, 2 set to project independent default | uint32 | write only |
 *  | 0x2527  | GPIO_STATE                       | 0             | Set logical level on GPIO pins (bitwise; 0=LOW, 1=HIGH)          | Bit#<br/>0 - external GPIO0<br/>1 - external GPIO1<br/>2 - external GPIO2<br/>3 - external GPIO3<br/>4 - internal GPIO_IN0<br/>5 - internal GPIO_IN1<br/>6 - internal GPIO_IN4<br/>7 - internal GPIO_IN5| read write |
 *  | 0x2528  | GPIO_DIRECTION                   | 0             | Set direction of GPIO pins (bitwise; 0=INPUT, 1=OUTPUT)          | Bit#<br/>0 - external GPIO0<br/>1 - external GPIO1<br/>2 - external GPIO2<br/>3 - external GPIO3<br/>4 - internal GPIO_IN0<br/>5 - internal GPIO_IN1<br/>6 - internal GPIO_IN4<br/>7 - internal GPIO_IN5| read write |
 *  | 0x2529  | FB_MODE						     | 0	         | Set feedback mode bitwise per channel (0=current, 1=voltage) *(2)| uint32 | read write |
 *  | 0x252A  | Pin_avg						     | N/A	         | Reading average input power (integration time = 1 second)        | float  | read only  |
 *  | 0x252B  | DEV_POWER_MASK                   | 0             | Set 3v3 for device bitwise per channel							| uint32 | read write |
 *  *(1) Calibration coefficients are enabled for measurements in this system only in official ICC-4-C builds<br/>
 *  *(2) Feedback mode selection is available only on drivers with HW revision 2 and greater
 *
 * The Miscellaneous system supports the following vectors (vectors have their own address space):
 *
 * | Address | Name                           | Default     | Description                            | Format and value    |
 * |---------|--------------------------------|-------------|----------------------------------------|---------------------|
 * | 0x2500  | i2c address list on channel0   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2501  | i2c address list on channel1   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2502  | i2c address list on channel2   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2503  | i2c address list on channel3   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2504  | output current all channels    |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2505  | output voltage all channels    |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2506  | load resistance all channels   |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2507  | analog inputs all channels     |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2508  | out.current calib.coef. chan#0 |{0,1,0,0,0,0}| 5th grade polynomial for chan#0        | 6*float, read write |
 * | 0x2509  | out.current calib.coef. chan#1 |{0,1,0,0,0,0}| 5th grade polynomial for chan#1        | 6*float, read write |
 * | 0x250A  | out.current calib.coef. chan#2 |{0,1,0,0,0,0}| 5th grade polynomial for chan#2        | 6*float, read write |
 * | 0x250B  | out.current calib.coef. chan#3 |{0,1,0,0,0,0}| 5th grade polynomial for chan#3        | 6*float, read write |
 * | 0x250C  | out.voltage calib.coef. chan#0 |{0,1,0,0,0,0}| 5th grade polynomial for chan#0        | 6*float, read write |
 * | 0x250D  | out.voltage calib.coef. chan#1 |{0,1,0,0,0,0}| 5th grade polynomial for chan#1        | 6*float, read write |
 * | 0x250E  | out.voltage calib.coef. chan#2 |{0,1,0,0,0,0}| 5th grade polynomial for chan#2        | 6*float, read write |
 * | 0x250F  | out.voltage calib.coef. chan#3 |{0,1,0,0,0,0}| 5th grade polynomial for chan#3        | 6*float, read write |
 * | 0x2510  | analog input calib.coef.chan#0 |{0,1,0,0,0,0}| 5th grade polynomial for chan#0        | 6*float, read write |
 * | 0x2511  | analog input calib.coef.chan#1 |{0,1,0,0,0,0}| 5th grade polynomial for chan#1        | 6*float, read write |
 * | 0x2512  | analog input calib.coef.chan#2 |{0,1,0,0,0,0}| 5th grade polynomial for chan#2        | 6*float, read write |
 * | 0x2513  | analog input calib.coef.chan#3 |{0,1,0,0,0,0}| 5th grade polynomial for chan#3        | 6*float, read write |
 * | 0x2514  | Uin voltage calib.coefficient  |{0,1,0,0,0,0}| 5th grade polynomial                   | 6*float, read write |
 * | 0x2515  | Iin voltage calib.coefficient  |{0,1,0,0,0,0}| 5th grade polynomial                   | 6*float, read write |
 * | 0x2516  | Ufe voltage calib.coefficient  |{0,1,0,0,0,0}| 5th grade polynomial                   | 6*float, read write |
 *
*/
    """

    @staticmethod
    def help():
        print(MRE3MiscFeatures.__doc__)

    _is_a_system = True

    def __init__(self, board=None):
        self.sys_id = 0x25
        self.reset_FW = {'id': self.sys_id << 8 | 0x00, 'type': int, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.FE_power = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.FE_voltage = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': None, 'range': None, 'default': 18.0,
                           'value': 18.0}
        self.PWM_frequency = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None, 'default': None,
                              'value': None}
        self.enable_out0 = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.enable_out1 = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.ADCI0 = {'id': self.sys_id << 8 | 0x08, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCI1 = {'id': self.sys_id << 8 | 0x09, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCV0 = {'id': self.sys_id << 8 | 0x0c, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCV1 = {'id': self.sys_id << 8 | 0x0d, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.DEV_POWER0 = {'id': self.sys_id << 8 | 0x10, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.DEV_POWER1 = {'id': self.sys_id << 8 | 0x11, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.DEV_TYPE0 = {'id': self.sys_id << 8 | 0x14, 'type': int, 'unit': None, 'range': None, 'default': None,
                          'value': None}
        self.DEV_TYPE1 = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None, 'default': None,
                          'value': None}
        self.UIN = {'id': self.sys_id << 8 | 0x18, 'type': float, 'unit': None, 'range': None, 'default': None,
                    'value': None}
        self.IIN = {'id': self.sys_id << 8 | 0x19, 'type': float, 'unit': None, 'range': None, 'default': None,
                    'value': None}
        self.UFE = {'id': self.sys_id << 8 | 0x1a, 'type': float, 'unit': None, 'range': None, 'default': None,
                    'value': None}
        self.AIN0 = {'id': self.sys_id << 8 | 0x1b, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}
        self.AIN1 = {'id': self.sys_id << 8 | 0x1c, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}
        self.WRITE_CTRL = {'id': self.sys_id << 8 | 0x20, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.LOAD_CH0 = {'id': self.sys_id << 8 | 0x21, 'type': float, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.LOAD_CH1 = {'id': self.sys_id << 8 | 0x22, 'type': float, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.enable_calibration = {'id': self.sys_id << 8 | 0x25, 'type': int, 'unit': None, 'range': None,
                                   'default': None, 'value': None}
        self.Operation_Mode = {'id': self.sys_id << 8 | 0x26, 'type': int, 'unit': None, 'range': None, 'default': None,
                               'value': None}
        self.GPIO_STATE = {'id': self.sys_id << 8 | 0x27, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.GPIO_DIRECTION = {'id': self.sys_id << 8 | 0x28, 'type': int, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.FB_MODE = {'id': self.sys_id << 8 | 0x29, 'type': int, 'unit': None, 'range': None, 'default': None,
                        'value': None}
        self.Pin_avg = {'id': self.sys_id << 8 | 0x2a, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.ProxyVoltage = {'id': self.sys_id << 8 | 0x2c, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}

        self.i2c_list_ch0 = {'id': self.sys_id << 8 | 0x00, 'type': bytes}
        self.i2c_list_ch1 = {'id': self.sys_id << 8 | 0x01, 'type': bytes}
        self.i2c_list_ch2 = {'id': self.sys_id << 8 | 0x02, 'type': bytes}
        self.i2c_list_ch3 = {'id': self.sys_id << 8 | 0x03, 'type': bytes}
        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    # Resets firmware of the driver
    def ResetFW(self):
        self.get_register('reset_FW')

    # Gets the frontend power supply state, 0 = false, 1 = true
    def GetFEpower(self):
        return self.get_register('FE_power')

    # Sets the frontend power supply state, 0 = false, 1 = true
    def SetFEpower(self, state=0):
        return self.set_register('FE_power', state)

    # Gets the frontend supply voltage, default is 12.0 V
    def GetFEvoltage(self):
        return self.get_register('FE_voltage')

    # Sets the frontend supply voltage, default is 12.0 V
    def SetFEvoltage(self, voltage=12.0):
        return self.set_register('FE_voltage', voltage)

    # Gets the output stage PWM frequency. Supported frequencies: 400,500,600,1000,1200
    def GetPWMfrequency(self):
        freq = self.get_register('PWM_frequency')
        if (freq == 0):
            return 400
        if (freq == 1):
            return 500
        if (freq == 2):
            return 600
        if (freq == 3):
            return 1000
        if (freq == 4):
            return 1200
        else:
            return 0

    # Sets the output stage PWM frequency. Supported frequencies: 400,500,600,1000,1200
    def SetPWMfrequency(self, frequency=1000):
        freq = -1
        if frequency == 400:
            freq = 0
        if frequency == 500:
            freq = 1
        if frequency == 600:
            freq = 2
        if frequency == 1000:
            freq = 3
        if frequency == 1200:
            freq = 4

        if freq != -1:
            return self.set_register('PWM_frequency', freq)
        else:
            raise Exception("Frequency value not supported (supported frequencies: 400,500,600,1000,1200)")

    # Gets enable output stage flag for specific channel, 0 = disabled, 1 = enabled
    def GetOutputState(self, channel):
        return self.get_register('enable_out' + str(channel))

    # Sets enable output stage flag for specific channel, 0 = disabled, 1 = enabled
    def SetOutputState(self, channel, state=0):
        return self.set_register('enable_out' + str(channel), state)

    # Reads current [A] on specific channel
    def GetADCcurrent(self, channel=0):
        return self.get_register('ADCI' + str(channel))

    # Reads voltage [V] on specific channel
    def GetADCvoltage(self, channel=0):
        return self.get_register('ADCV' + str(channel))

    # Gets 3v3 for device on specific channel
    def GetDevicePower(self, channel):
        return self.get_register('DEV_POWER' + str(channel))

    # Sets 3v3 for device on specific channel
    def SetDevicePower(self, channel, state=0):
        return self.set_register('DEV_POWER' + str(channel), state)

    def GetDevicePowerMask(self):
        reg = self.get_register('DEV_POWER_MASK')
        return reg[0]

    def SetDevicePowerMask(self, mask=0):
        self.set_register('DEV_POWER_MASK', mask)

    # Gets device type connected to specific channel
    def GetDeviceType(self, channel):
        return self.get_register('DEV_TYPE' + str(channel))

    # Gets input voltage
    def GetUIN(self):
        return self.get_register('UIN')

    # Gets input current
    def GetIIN(self):
        return self.get_register('IIN')

    # Gets FE voltage
    def GetUFE(self):
        return self.get_register('UFE')

    # Gets Proxy Board supply voltage
    def GetProxyVoltage(self):
        return self.get_register('ProxyVoltage')

    # Gets analog input voltage on specific channel
    def GetAnalogInput(self, channel=0):
        return self.get_register('AIN' + str(channel))

    # Gets load resistance on specific channel
    def GetResistance(self, channel=0):
        return self.get_register('LOAD_CH' + str(channel))

    # Returns current specific operation mode
    # 0 - Open loop,
    # 1 - Close loop Optical Feedback,
    # 2 - Close loop XY,
    # 3 - Close loop Optical Feedback OFA only,
    # 4 - Close loop Optical Feedback OFB only
    # 5 - Close loop X only ,
    # 6 - Close loop Y only
    def GetOperationMode(self):
        return self.get_register('Operation_Mode')

    # Configures both channels of driver into specific mode
    # 0 - Open loop,
    # 1 - Close loop Optical Feedback,
    # 2 - Close loop XY,
    # 3 - Close loop Optical Feedback OFA only,
    # 4 - Close loop Optical Feedback OFB only
    # 5 - Close loop X only ,
    # 6 - Close loop Y only
    def SetOperationMode(self, value):
        return self.set_register('Operation_Mode', value)

    # Gets WC state
    def GetWcState(self):
        return self.get_register('WRITE_CTRL')

    # Sets state of WC output signal
    def SetWcState(self, value):
        return self.set_register('WRITE_CTRL', value)

    # Enables/disables calibration coefficients for measurements in this system, 0 = disabled, 1 = enabled
    def EnableCalCoefficients(self, enable=1):
        return self.set_register('enable_calibration', enable)

    # Gets logical level on GPIO pins (bitwise), 0 = LOW, 1 = HIGH
    def GetGPIOstate(self):
        return self.get_register('GPIO_STATE')

    # Sets logical level on GPIO pins (bitwise), 0 = LOW, 1 = HIGH
    def SetGPIOstate(self, state=0):
        return self.set_register('GPIO_STATE', state)

    # Gets direction of GPIO pins (bitwise), 0 = INPUT, 1 = OUTPUT
    def GetGPIOdirection(self):
        return self.get_register('GPIO_DIRECTION')

    # Sets direction of GPIO pins (bitwise), 0 = INPUT, 1 = OUTPUT
    def SetGPIOdirection(self, direction=0):
        return self.set_register('GPIO_DIRECTION', direction)

    # Gets feedback mode bitwise per channel, 0 = current, 1 = voltage
    def GetFeedbackMode(self):
        return self.get_register('FB_MODE')

    # Sets feedback mode bitwise per channel, 0 = current, 1 = voltage
    def SetFeedbackMode(self, state=0):
        return self.set_register('FB_MODE', state)

    # Gets average input power (integration time = 1 second)
    def GetAverageInputPower(self):
        return self.get_register('Pin_avg')

    # Gets 16 bytes representing specific I2C address for specific channel
    def GetI2CList(self, channel):
        if channel == 0:
            return self._board.get_vector(self.i2c_list_ch0, 0, 16)[0]
        if channel == 1:
            return self._board.get_vector(self.i2c_list_ch1, 0, 16)[0]
        if channel == 2:
            return self._board.get_vector(self.i2c_list_ch2, 0, 16)[0]
        if channel == 3:
            return self._board.get_vector(self.i2c_list_ch3, 0, 16)[0]


class Logger(System):
    """
Device Functionality - Logger
System ID: 0x24

A system for logging the values of various readable registers.

+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Register Name             | Id   | Type        | Unit | Range | Default | Comment                                   |
+===========================+======+=============+======+=======+=========+===========================================+
| logged_register_0         | 0x00 | uint 32-bit |None  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_1         | 0x01 | uint 32-bit |None  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_2         | 0x02 | uint 32-bit |None  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_3         | 0x03 | uint 32-bit |None  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_4         | 0x04 | uint 32-bit |None  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_5         | 0x05 | uint 32-bit |None  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| run                       | 0x10 | uint 32-bit |Bool  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| sampling_frequency        | 0x11 | float       |Hz    |       | 40000   |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| minimum sampling_frequency| 0x12 | float       |Hz    |      | 40000/(2^32 -1)         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| maximum sampling_frequency| 0x13 | float       |Hz     |       | 40000   |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Logger trigger register   | 0x14 | uint 32-bit |None    |      | 0       |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Logger trigger mode       | 0x15 | uint 32-bit |None |       | 0       |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Logger trigger value      | 0x16 | float       |None |      | 0       |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Logger trigger format     | 0x17 | uint 32-bit |None |       | 0       |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
    """

    def __init__(self, board=None):
        self.sys_id = 0x24
        self._readonly = False
        self.logged_register_0 = {'id': self.sys_id << 8 | 0x00, 'type': int, 'unit': None, 'range': None,
                                  'default': 0xe802}
        self.logged_register_1 = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None,
                                  'default': 0xe902}
        self.logged_register_2 = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None,
                                  'default': 0x2300}
        self.logged_register_3 = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None,
                                  'default': 0x2301}
        self.logged_register_4 = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None,
                                  'default': 0x2302}
        self.logged_register_5 = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None,
                                  'default': 0x2303}

        self.run = {'id': self.sys_id << 8 | 0x10, 'type': int, 'unit': bool, 'range': [0, 1], 'default': False}
        self.sampling_frequency = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': 'Hz', 'range': None,
                                   'default': 40000}

        self.register_log_0 = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_1 = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_2 = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_3 = {'id': self.sys_id << 8 | 0x03, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_4 = {'id': self.sys_id << 8 | 0x04, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_5 = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': None, 'range': None, 'default': 0}

        self.log_trigger_reg = {'id': self.sys_id << 8 | 0x14, 'type': int, 'unit': None, 'range': None, 'default': 0}
        self.log_trigger_mode = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None, 'default': 0}
        self.log_trigger_value = {'id': self.sys_id << 8 | 0x16, 'type': float, 'unit': None, 'range': None,
                                  'default': 0}
        self.log_trigger_format = {'id': self.sys_id << 8 | 0x17, 'type': int, 'unit': None, 'range': None,
                                   'default': 0}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def GetLoggedRegister(self, log_number):
        return self.get_register('logged_register_{}'.format(log_number))

    def SetLoggedRegister(self, log_number, value):
        # set new logged register
        set_response = self.set_register('logged_register_{}'.format(log_number), value)
        # collect register dictionary from new register
        newsys_id = value >> 8
        new_sys_registers = self._board.systems[newsys_id]['registers']
        # set logged register to new value internally
        new_reg = [new_sys_registers[item] for item in new_sys_registers if new_sys_registers[item]['id'] == value][0]
        self.__dict__['register_log_{}'.format(log_number)].update(new_reg)
        # set register log output type internally
        self.__dict__['register_log_{}'.format(log_number)].update({'type': new_reg['type']})
        return set_response

    def RunLogger(self):
        return self.set_register('run', 1)

    def StopLogger(self):
        return self.set_register('run', 0)

    def GetLog(self, log_number, index, count):
        vec = []
        # end_index = index + count
        if count < CHUNK_SIZE:
            return self._GetLogSegment(log_number, index, count)
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._GetLogSegment(log_number, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._GetLogSegment(log_number, index + count - remainder, remainder)
            vec.extend(aux)
        return vec

    def _GetLogSegment(self, log_number, index, count):
        register = self.__dict__['register_log_{}'.format(log_number)]
        return self._board.get_vector(register, index, count)

    def to_int(self, float_v):
        return [struct.unpack('>i', struct.pack(">f", v))[0] for v in float_v]

    def GetSamplingFrequency(self):
        return self.get_register('sampling_frequency')

    def SetSamplingFrequency(self, value):
        return self.set_register('sampling_frequency', value)

    def SetTriggerReg(self, value):
        return self.set_register('log_trigger_reg', value)

    def GetTriggerReg(self):
        return self.get_register('log_trigger_reg')

    def SetTriggerMode(self, value):
        return self.set_register('log_trigger_mode', value)

    def GetTriggerMode(self):
        return self.get_register('log_trigger_mode')

    def SetTriggerValue(self, value):
        return self.set_register('log_trigger_value', value)

    def GetTriggerValue(self):
        return self.get_register('log_trigger_value')

    def SetTriggerFormat(self, value):
        return self.set_register('log_trigger_format', value)

    def GetTriggerFormat(self):
        return self.get_register('log_trigger_format')


# sensor systems
class OpticalFeedback(System):
    """
Device Functionality - Optical Feedback

The optical feedback system provides information about the actual position of the mirror in optical feedback units.

System ID: 0x23

+---------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Register Name | Id   | Type        | Unit | Range | Default | Comment                                          |
+===============+======+=============+======+=======+=========+==================================================+
| of_a          | 0x00 |float 32-bit |None  |       |         |                                                  |
+---------------+------+-------------+------+-------+---------+--------------------------------------------------+
| of_b          | 0x01 |float 32-bit |None  |       |         |                                                  |
+---------------+------+-------------+------+-------+---------+--------------------------------------------------+
    """

    @staticmethod
    def help():
        print(OpticalFeedback.__doc__)

    _is_a_system = True

    def __init__(self, board=None):
        self.sys_id = 0x23
        self.of_a = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}
        self.of_b = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def GetOpticalFeedbackA(self):
        return self.get_register('of_a')

    def GetOpticalFeedbackB(self):
        return self.get_register('of_b')


class MRE3TemperatureManager(System):
    r"""
        Device Functionality - Device Temperature Readout
        System ID: 0x22
        If this threshold is reached the output of the driver is disabled to cool down.
        Temperature has to fall by 10 degrees so that the output is enabled again
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        | Register Name                   | Id   | Type        | Unit | Range | Default | Comment                      |
        +=====================+======+=============+======+=======+=========+==========================================+
        |actuator_temperature             | 0x00 | float  |°C    |       |N/A       |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |actuator_temp_threshold          | 0x01 | float  |°C    |       |85        |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |output_stage_board_temp          | 0x02 | float  |°C    |       |N/A       |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |output_stage_board_temp_threshold| 0x03 | float  |°C    |       |80        |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |proxy_board_temperature          | 0x04| float  |°C     |       |N/A       |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |proxy_board_temperature_threshold| 0x05 | float  |°C    |       |85        |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |mcu  _temp_threshold            | 0x06 | float  |°C    |       |N/A       |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |mcu_temp_threshold              | 0x07 | float  |°C    |       |85        |Degrees Celsius               |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
    """

    @staticmethod
    def help():
        print(MRE3TemperatureManager.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        self.sys_id = 0x22

        self.device_temperature = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': '°C', 'range': None,
                                   'default': None, 'value': None}
        self.device_temp_threshold = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': '°C', 'range': None,
                                      'default': 85, 'value': None}

        self.board_out_temperature = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': '°C', 'range': None,
                                      'default': None, 'value': None}
        self.board_out_threshold = {'id': self.sys_id << 8 | 0x03, 'type': float, 'unit': '°C', 'range': None,
                                    'default': 80, 'value': None}
        self.proxy_temperature = {'id': self.sys_id << 8 | 0x04, 'type': float, 'unit': '°C', 'range': None,
                                  'default': None, 'value': None}
        self.proxy_threshold = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': '°C', 'range': None,
                                'default': 85, 'value': None}
        self.mcu_temperature = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': '°C', 'range': None,
                                'default': None, 'value': None}
        self.mcu_temperature_threshold = {'id': self.sys_id << 8 | 0x07, 'type': float, 'unit': '°C', 'range': None,
                                          'default': 90, 'value': None}
        System.__init__(self, board=board)

    # Gets actual device temperature of the active channel. Active cahnnel is set by
    # 'Status.SetDeviceEEPROMactiveChannel(channel_index)'. This temperature can be also obtained by
    # channel's TemperatureManager 'Channel_0.TemperatureManager.GetDeviceTemperature()'
    def GetDeviceTemperature(self):
        return self.get_register('device_temperature')

    # Gets device temperature threshold of the active channel. Active cahnnel is set by
    # 'Status.SetDeviceEEPROMactiveChannel(channel_index)'. If this threshold is reached the output of the driver is
    # disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again. This temperature
    # threshold can be also obtained by channel's TemperatureManager
    # 'Channel_0.TemperatureManager.GetDeviceTemperatureThreshold()'
    def GetDeviceTemperatureThreshold(self):
        return self.get_register('device_temp_threshold')

    # Sets device temperature threshold of the active channel. Active cahnnel is set by
    # 'Status.SetDeviceEEPROMactiveChannel(channel_index)'. If this threshold is reached the output of the driver is
    # disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again. This temperature
    # threshold can be also obtained by channel's TemperatureManager
    # 'Channel_0.TemperatureManager.GetDeviceTemperatureThreshold()'
    def SetDeviceTemperatureThreshold(self, threshold=0):
        return self.set_register('device_temp_threshold', threshold)

    # Gets driver output stage temperature
    def GetBoardOutputStageTemperature(self):
        return self.get_register('board_out_temperature')

    # Gets driver output stage temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def GetBoardOutputStageTemperatureThreshold(self):
        return self.get_register('board_out_threshold')

    # Sets driver output stage temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def SetBoardOutputStageTemperatureThreshold(self, threshold=0):
        return self.set_register('board_out_threshold', threshold)

    # Gets proxy board temperature
    def GetProxyTemperature(self):
        return self.get_register('proxy_temperature')

    # Gets proxy board temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def GetProxyTemperatureThreshold(self):
        return self.get_register('proxy_threshold')

    # Sets proxy board temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def SetProxyTemperatureThreshold(self, threshold=0):
        return self.set_register('proxy_threshold', threshold)

    def GetMcuTemperature(self):
        return self.get_register('mcu_temperature')

    def GetMcuTemperatureThreshold(self):
        return self.get_register('mcu_temperature_threshold')

    # Sets driver power supply temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def SetMcuTemperatureThreshold(self, threshold=0):
        return self.set_register('mcu_temperature_threshold', threshold)


def systems():
    all_systems = inspect.getmembers(sys.modules[__name__], inspect.isclass)
    all_systems = list(zip(*all_systems))[1]
    sys_dict = {}
    for system in all_systems:
        if hasattr(system, '_is_a_system'):
            try:
                # init instance of each channel in system to get attributes
                for i in range(MRE3_PHOTO_DIODES_CNT):
                    sys_obj = system(channel=i)
                    sys_id = sys_obj.sys_id
                    reg_dict = dict(sys_obj.register_list)
                    sys_dict.update({sys_id: {'name': sys_obj.name, 'registers': reg_dict}})
            except TypeError:
                # system does not have multiple channels
                sys_obj = system()
                sys_id = sys_obj.sys_id
                reg_dict = dict(sys_obj.register_list)
                sys_dict.update({sys_id: {'name': sys_obj.name, 'registers': reg_dict}})
            except AttributeError:
                # abstract system, do not add to list. this shouldn't happen
                pass
    return sys_dict


class MRE3StaticInput(InputStage):
    r"""
Input Channel Systems - USB/UART
System IDs: 0x50 through 0x57

+----------------+------+-------------+----------+-------------+---------+---------------------------------------+
| Register Name  | Id   | Type        | Unit     | Range       | Default | Comment                               |
+================+======+=============+==========+=============+=========+=======================================+
| current        | 0x00 | float 32-bit| A        | -1.13 to 1.13 | 0.0     |                                       |
+----------------+------+-------------+----------+-------------+---------+---------------------------------------+
| OF             | 0x00 | float 32-bit| A        |             | 0.0     |                                       |
+----------------+------+-------------+----------+-------------+---------+---------------------------------------+
| XY             | 0x00 | float 32-bit| A        | -1.0 to 1.0 | 0.0     |                                       |
+----------------+------+-------------+----------+-------------+---------+---------------------------------------+
| Type           | 0x00 | float 32-bit| A        |             | 0.0     |                                       |
+----------------+------+-------------+----------+-------------+---------+---------------------------------------+
| FP             | 0x00 | float 32-bit| A        |             | 0.0     |                                       |
+----------------+------+-------------+----------+-------------+---------+---------------------------------------+
| Unitless       | 0x00 | float 32-bit| A        |             | 0.0     |                                       |
+----------------+------+-------------+----------+-------------+---------+---------------------------------------+

    """

    @staticmethod
    def help():
        print(StaticInput.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x50 | channel
        self._readonly = False

        self.current = {'id': self.sys_id << 8 | 0x00,
                        'type': float,
                        'unit': 'A',
                        'range': [-1.13, 1.13],
                        'default': 0.0,
                        'value': 0.0}

        self.of = {'id': self.sys_id << 8 | 0x01,
                   'type': float,
                   'unit': None,
                   'range': [-1, 1],
                   'default': 0.0,
                   'value': 0.0}

        self.xy_value = {'id': self.sys_id << 8 | 0x02,
                         'type': float,
                         'unit': 'XY',
                         'range': [-1, 1],
                         'default': 0.0,
                         'value': 0.0}

        self.active_type = {'id': self.sys_id << 8 | 0x03,
                            'type': UnitType,
                            'unit': None,
                            'range': None,
                            'default': 0,
                            'value': 0}

        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    # Sets current on this channel [A]
    def SetCurrent(self, value):
        return self.set_register('current', value)

    # Gets current on this channel [A]
    def GetCurrent(self):
        return self.get_register('current')

    def SetOF(self, value):
        return self.set_register('of', value)

    def GetOF(self):
        return self.get_register('of')

    def SetXY(self, value):
        return self.set_register('xy_value', value)

    def GetXY(self):
        return self.get_register('xy_value')

    def GetActiveType(self):
        return self.get_register('active_type')


class RadialBasisFunction(System):
    r"""

The radial basis function calculation system provides precise mirror unary XY coordinate system. Calculation is based on
multiple point calibration and transformation from optical feedback to unary circular XY coordinates.

System IDs: 0x3B

    * | Address | Name                   | Default Value | Description                        | Type   | Access    |
    * |---------|------------------------|---------------|------------------------------------|--------|-----------|
    * | 0x3B00  | Mirror coordinate X    | N/A           | Mirror unary circle X coordinate   | float  | read only |
    * | 0x3B01  | Mirror coordinate Y    | N/A           | Mirror unary circle Y coordinate   | float  | read only |

    """

    @staticmethod
    def help():
        print(RadialBasisFunction.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x3B

        self.mirror_coordinate_x = {'id': self.sys_id << 8 | 0x00,
                                    'type': float,
                                    'unit': None,
                                    'range': None,
                                    'default': None,
                                    'value': None}

        self.mirror_coordinate_y = {'id': self.sys_id << 8 | 0x01,
                                    'type': float,
                                    'unit': None,
                                    'range': None,
                                    'default': None,
                                    'value': None}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    # Gets current on this channel [A]
    def GetMirrorCoordinateX(self):
        return self.get_register('mirror_coordinate_x')

    # Gets current on this channel [A]
    def GetMirrorCoordinateY(self):
        return self.get_register('mirror_coordinate_y')


class MRE3BoardEEPROM(BoardEEPROM):
    r"""
    * Board EEPROM system ID: <b>0x20</b>
    *
    * Board EEPROM system provides read and write functionality to the EEPROM located in the driver.
    * By default EEPROM data are write protected. To write data, the user has to explicitly unlock
    * the EEPROM by writing the key value to the lock register.
    *
    * ## Register Map:
    *
    * | Address | Name                           | Default Value | Description                                                       | Type   | Access    |
    * |---------|--------------------------------|---------------|-------------------------------------------------------------------|--------|-----------|
    * | 0x2000  | Lock                           | 1             | write the key to unlock, anything else to lock                    | float  | read write| Key value: 0x3f4744f6 (float 0.778396)
    * | 0x2001  | Board EEPROM version           | N/A           |                                                                   | uint16 | read only |
    * | 0x2002  | Board EEPROM subversion        | N/A           |                                                                   | uint8  | read only |
    * | 0x2003  | Part number                    | N/A           | Part number as an integer (2000mA->14521500, 500mA->14521400)     | uint32 | read only |
    * | 0x2004  | Part configuration             | N/A           |                                                                   | uint8  | read only |
    * | 0x2005  | Product version                | N/A           |                                                                   | uint8  | read only |
    * | 0x2006  | NOT USED                       | true or 1     | DHCP enabled if not 0                                             | bool   | read write|
    * | 0x2007  | NOT USED                       | 5000          |                                                                   | bool   | read write|
    * | 0x2008  | NOT USED                       | 30311         |                                                                   | bool   | read write|
    * | 0x2009  | I2C slave address              | 0x03          |                                                                   | uint8  | read write|
    * | 0x200A  | FE_autostart                   | true or 1     | Autostart if value!=0                                             | uint8  | read write|
    * | 0x200B  | FE_voltage                     | 18.0          |                                                                   | float  | read write|
    * | 0x200C  | PWM_freq                       | 0             | Startup PWM freq: 0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz  | uint8  | read write|
    * | 0x200D  | PWM_enable_chan_mask           | 3            | Enable output PWM driver IC on channel (bitwise)                  | uint8  | read write|
    * | 0x200E  | Device_detect_chan_mask        | 3            | Enable autodetection on channel (bitwise)                         | uint8  | read write|
    * | 0x200F  | Device_3V3_state_chan_mask     | 0             | Enable device 3V3 startup state on channel (bitwise)              | uint8  | read write|
    * | 0x2010  | PS_temp_limit                  | 80            | Power supply temperature limit for shutdown                       | float  | read write|
    * | 0x2011  | PS_temp_hyst                   | 10            | Power supply temperature hysteresis for restart                   | float  | read write|
    * | 0x2012  | OS_temp_limit                  | 80            | Output stage temperature limit for shutdown                       | float  | read write|
    * | 0x2013  | OS_temp_hyst                   | 10            | Output stage temperature hysteresis for restart                   | float  | read write|
    * | 0x2014  | Start_auto_config              | 0             | 1=internal or 2=ext.triger starts auto-actuation (0=off)          | uint32 | read write|
    * | 0x2015  | Calibration Time-stamp         | N/A           | Unix Time format (seconds since 1.1.1970)                         | uint32 | read write|
    * | 0x2016  | UART baudrate configuration    | 0-Autobaudrate| Configuration of UART baudrate in Baud/s, 0 means Autobaudrate    | uint32 | read write|
    * | 0x2017  | Slave I2C register count       | 2             | Set # of registers which can be read in one SignalFlow loop 1/2/4 | uint32 | read write|
    * | 0x2018  | Power On Delay                 | 0             | Delay before board initialisation in milliseconds (0-65535)       | uint32 | read write|
    * | 0x2019  | Board EEPROM Parsing result    | 0             | Result of Board EEPROM parsing. Value 0 means OK. See error codes | uint32 | read only |
    * | 0x201A  | Positive current limit chan0   | 1130          | Positive current limit for unknown devices in mA - chan0          | uint16 | read write|
    * | 0x201B  | Negative current limit chan0   | 1130          | Negative current limit for unknown devices in mA - chan0          | uint16 | read write|
    * | 0x201C  | Positive current limit chan1   | 1130          | Positive current limit for unknown devices in mA - chan1          | uint16 | read write|
    * | 0x201D  | Negative current limit chan1   | 1130          | Negative current limit for unknown devices in mA - chan1          | uint16 | read write|
    * | 0x2022  | Device I2C clock frequency     | 100           | Device I2C clock freq. in kHz: allowed values: 25, 50, 100, 200, 400 kHz| uint16 | read write|
    *
    * The board EEPROM system supports the following vectors (vectors have their own address space):
    *
    * | Address | Name                           | Default  | Description                 | Format and value |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    * | 0x2000  | Board EEPROM                   |   N/A    | supports bytes up to 0x2000 |                  |
    * | 0x2001  | Board serial number            |   N/A    | 8 bytes                     | read only        |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    """

    @staticmethod
    def help():
        print(BoardEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        BoardEEPROM.__init__(self, board=board)
        self.eeprom_version = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.eeprom_subversion = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None,
                                  'default':
                                      None, 'value': None}
        self.part_number = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.part_config = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.prod_version = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None,
                             'default': None, 'value': None}
        self.I2C_slave_addr = {'id': self.sys_id << 8 | 0x09, 'type': int, 'unit': None, 'range': None,
                               'default': None, 'value': None}
        self.FE_autostart = {'id': self.sys_id << 8 | 0x0A, 'type': int, 'unit': None, 'range': None,
                             'default': None, 'value': None}
        self.FE_voltage = {'id': self.sys_id << 8 | 0x0B, 'type': float, 'unit': None, 'range': None,
                           'default': None,
                           'value': None}
        self.PWM_freq = {'id': self.sys_id << 8 | 0x0C, 'type': int, 'unit': None, 'range': None,
                         'default': None, 'value': None}
        self.PWM_enable_chan_mask = {'id': self.sys_id << 8 | 0x0D, 'type': int, 'unit': None, 'range': None,
                                     'default': None, 'value': None}
        self.Device_detect_chan_mask = {'id': self.sys_id << 8 | 0x0E, 'type': int, 'unit': None, 'range': None,
                                        'default': None, 'value': None}
        self.Device_3V3_state_chan_mask = {'id': self.sys_id << 8 | 0x0F, 'type': int, 'unit': None, 'range': None,
                                           'default': None, 'value': None}
        self.PS_temp_limit = {'id': self.sys_id << 8 | 0x10, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.PS_temp_hyst = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.OS_temp_limit = {'id': self.sys_id << 8 | 0x12, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.OS_temp_hyst = {'id': self.sys_id << 8 | 0x13, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.StartControlMode = {'id': self.sys_id << 8 | 0x14, 'type': int, 'unit': None, 'range': None, 'default':
            0, 'value': None}
        self.Cal_timestamp = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None,
                              'default': None, 'value': None}
        self.Input_control_setup = {'id': self.sys_id << 8 | 0x16, 'type': int, 'unit': None, 'range': None,
                                    'default': None, 'value': None}
        self.I2C_slave_num_of_registers = {'id': self.sys_id << 8 | 0x17, 'type': int, 'unit': None, 'range': None,
                                           'default': 2, 'value': None}
        self.power_on_delay = {'id': self.sys_id << 8 | 0x18, 'type': int, 'unit': None, 'range': None,
                               'default': 0, 'value': None}
        self.board_EEPROM_parsing_result = {'id': self.sys_id << 8 | 0x19, 'type': int, 'unit': None, 'range': None,
                                            'default': 0, 'value': None}
        self.positive_current_limit_channel0 = {'id': self.sys_id << 8 | 0x1A, 'type': int, 'unit': None, 'range': None,
                                                'default': 1130, 'value': None}
        self.negative_current_limit_channel0 = {'id': self.sys_id << 8 | 0x1B, 'type': int, 'unit': None, 'range': None,
                                                'default': 1130, 'value': None}
        self.positive_current_limit_channel1 = {'id': self.sys_id << 8 | 0x1C, 'type': int, 'unit': None, 'range': None,
                                                'default': 1130, 'value': None}
        self.negative_current_limit_channel1 = {'id': self.sys_id << 8 | 0x1D, 'type': int, 'unit': None, 'range': None,
                                                'default': 1130, 'value': None}
        self.dev_I2C_clock_freq = {'id': self.sys_id << 8 | 0x22, 'type': int, 'unit': None, 'range': None,
                                                'default': 100, 'value': None}

        self.eeprom = {'id': self.sys_id << 8, 'type': bytes}
        self.serial_number = {'id': self.sys_id << 8 | 0x01, 'type': bytes}

    # Gets board EEPROM version
    def GetEepromVersion(self):
        return self.get_register('eeprom_version')

    # Gets board EEPROM subversion
    def GetEepromSubVersion(self):
        return self.get_register('eeprom_subversion')

    # Gets board serial number
    def GetSerialNumber(self):
        return self._board.get_vector(self.serial_number, 0, 8)[0]

    # Gets board I2C address
    def GetI2Caddr(self):
        return self.get_register('I2C_slave_addr')

    # Sets board I2C address
    def SetI2Caddr(self, addr):
        return self.set_register('I2C_slave_addr', addr)

    # Gets board FE autostart flag, 0 = disabled, 1 = enabled
    def GetFEautostart(self):
        return self.get_register('FE_autostart')

    # Sets board FE autostart flag, 0 = disabled, 1 = enabled
    def SetFEautostart(self, val):
        return self.set_register('FE_autostart', val)

    # Gets board FE voltage
    def GetFEvoltage(self):
        return self.get_register('FE_voltage')

    # Sets board FE voltage
    def SetFEvoltage(self, val):
        return self.set_register('FE_voltage', val)

    # Gets board PWM startup frequency,  0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz
    def GetPWMfreq(self):
        return self.get_register('PWM_freq')

    # Sets board PWM startup frequency,  0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz
    def SetPWMfreq(self, val):
        return self.set_register('PWM_freq', val)

    # Enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetPWMenableChanMask(self, mask):
        return self.set_register('PWM_enable_chan_mask', mask)

    # Gets flag which enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetPWMenableChanMask(self):
        return self.get_register('PWM_enable_chan_mask')

    # Enables device autodetection (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDeviceDetectChanMask(self, val):
        return self.set_register('Device_detect_chan_mask', val)

    # Gets device autodetection flag (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDeviceDetectChanMask(self):
        return self.get_register('Device_detect_chan_mask')

    # Enables device 3V3 startup state on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDevice3V3chanMask(self, val):
        return self.set_register('Device_3V3_state_chan_mask', val)

    # Gets device 3V3 startup state flag on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDevice3V3chanMask(self):
        return self.get_register('Device_3V3_state_chan_mask')

    # Sets power supply temperature limit for shutdown
    def SetPStempLimit(self, val):
        return self.set_register('PS_temp_limit', val)

    # Gets power supply temperature limit for shutdown
    def GetPStempLimit(self):
        return self.get_register('PS_temp_limit')

    # Sets power supply temperature hysteresis for restart
    def SetPStempHyst(self, val):
        return self.set_register('PS_temp_hyst', val)

    # Gets power supply temperature hysteresis for restart
    def GetPStempHyst(self):
        return self.get_register('PS_temp_hyst')

    # Sets output stage temperature limit for shutdown
    def SetOStempLimit(self, val):
        return self.set_register('OS_temp_limit', val)

    # Gets output stage temperature limit for shutdown
    def GetOStempLimit(self):
        return self.get_register('OS_temp_limit')

    # Sets output stage temperature hysteresis for restart
    def SetOStempHyst(self, val):
        return self.set_register('OS_temp_hyst', val)

    # Gets output stage temperature hysteresis for restart
    def GetOStempHyst(self):
        return self.get_register('OS_temp_hyst')

    # Sets start up control mode (open loop/close loop)
    def SetStartControlMode(self, val):
        return self.set_register('StartControlMode', val)

    # Gets start up control mode (open loop/close loop)
    def GetStartControlMode(self):
        return self.get_register('StartControlMode')

    # Gets board calibration timestamp
    def GetCalTimestamp(self):
        return self.get_register('Cal_timestamp')

    def SetControlSetup(self, addr):
        return self.set_register('Input_control_setup', addr)

    def GetControlSetup(self):
        return self.get_register('Input_control_setup')

    def SetSlaveNumOfRegisters(self, addr):
        return self.set_register('I2C_slave_num_of_registers', addr)

    def GetSlaveNumOfRegisters(self):
        return self.get_register('I2C_slave_num_of_registers')

    def SetPowerOnDelay(self, addr):
        return self.set_register('power_on_delay', addr)

    def GetPowerOnDelay(self):
        return self.get_register('power_on_delay')

    def GetEEPROMParsingResult(self):
        return self.get_register('board_EEPROM_parsing_result')

    def SetPositiveCurrentLimitChannel0(self, addr):
        return self.set_register('positive_current_limit_channel0', addr)

    def GetPositiveCurrentLimitChannel0(self):
        return self.get_register('positive_current_limit_channel0')

    def SetNegativeCurrentLimitChannel0(self, addr):
        return self.set_register('negative_current_limit_channel0', addr)

    def GetNegativeCurrentLimitChannel0(self):
        return self.get_register('negative_current_limit_channel0')

    def SetPositiveCurrentLimitChannel1(self, addr):
        return self.set_register('positive_current_limit_channel1', addr)

    def GetPositiveCurrentLimitChannel1(self):
        return self.get_register('positive_current_limit_channel1')

    def SetNegativeCurrentLimitChannel1(self, addr):
        return self.set_register('negative_current_limit_channel1', addr)

    def GetNegativeCurrentLimitChannel1(self):
        return self.get_register('negative_current_limit_channel1')

    def GetDeviceI2CclockFreq(self):
        return self.get_register('dev_I2C_clock_freq')

    def SetDeviceI2CclockFreq(self, value):
        return self.set_register('dev_I2C_clock_freq', value)

    def VerifyEEPROM(self, index, vector):
        stored_eeprom = self.GetEEPROM(index, len(vector))
        return stored_eeprom == vector, stored_eeprom

    def LockEEPROM(self, enable=True):
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    def SetSerialNumber(self, serial):
        return self._board.set_vector(self.serial_number, 0, serial)

    def SetCalTimestamp(self, timestamp):
        return self.set_register('Cal_timestamp', timestamp)
