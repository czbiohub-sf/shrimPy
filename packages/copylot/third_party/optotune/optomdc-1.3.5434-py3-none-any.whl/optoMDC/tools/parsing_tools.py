from optoKummenberg.tools.parsing_tools import *

def parse_error_flags_mre2(error_flag_data: int):
    r"""
    Parses error flag register values. Given error number, returns error string.

    Parameters
    ----------
    error_flag_data : int
        Error code hex number, will convert if string.

    Returns
    -------
    code: str
        Error code dictionary.
    """
    bits = format(error_flag_data, '#032b')[2::]
    error_result = {
        'Proxy Disconnected': bool(int(bits[29])),
        'Proxy Temperature Threshold Reached': bool(int(bits[28])),
        'Mirror Temperature Threshold Reached': bool(int(bits[27])),
        'Mirror EEPROM Invalid': bool(int(bits[26])),
        'Mirror Unstable': bool(int(bits[25])),
        'Linear Output Limit Reached': bool(int(bits[24])),
        'Linear Output Average Limit Reached': bool(int(bits[23])),
        'XY Input Trimmed': bool(int(bits[22])),
        'Proxy Was Disconnected': bool(int(bits[21])),
        'Proxy Temperature Threshold Was Reached': bool(int(bits[20])),
        'Mirror Temperature Threshold Was Reached': bool(int(bits[19])),
        'Linear Output Limit Was Reached': bool(int(bits[18])),
        'Linear Output Average Limit Was Reached': bool(int(bits[17])),
        'XY Input Was Trimmed': bool(int(bits[16])),
        'Reserved': bits[0:16]
    }

    return error_result


def parse_error_flags_mre3(error_flag_data: int):
    r"""
    Parses error flag register values. Given error number, returns error string.

    Parameters
    ----------
    error_flag_data : int
        Error code hex number, will convert if string.

    Returns
    -------
    code: str
        Error code dictionary.
    """
    bits = format(error_flag_data, '#032b')[2::]
    error_result = {
        'Proxy Disconnected': bool(int(bits[0])),
        'Proxy Temperature Threshold Reached': bool(int(bits[1])),
        'Mirror Temperature Threshold Reached': bool(int(bits[2])),
        'Mirror EEPROM Invalid': bool(int(bits[3])),
        'Mirror Unstable': bool(int(bits[4])),
        'Linear Output Limit Reached': bool(int(bits[5])),
        'Linear Output Average Limit Reached': bool(int(bits[6])),
        'XY Input Trimmed': bool(int(bits[7])),
        'Proxy Was Disconnected': bool(int(bits[8])),
        'Proxy Temperature Threshold Was Reached': bool(int(bits[9])),
        'Mirror Temperature Threshold Was Reached': bool(int(bits[10])),
        'Linear Output Limit Was Reached': bool(int(bits[11])),
        'Linear Output Average Limit Was Reached': bool(int(bits[12])),
        'XY Input Was Trimmed': bool(int(bits[13])),
        'Vcc Fe Fault Condition': bits[14],
        'Vcc Fe Had Fault Condition': bits[15],
        'Channel 0 output fault condition': bits[16],
        'Channel 0 output had fault condition': bits[17],
        'Channel 1 output fault condition': bits[18],
        'Channel 1 output had fault condition': bits[19],
        'Driver over-heat fault': bits[20],
        'Driver had over-heat fault': bits[21],
        'Device on proxy (mirror) not detected': bits[22],
        'Device on proxy (mirror) was not detected': bits[23],
        'Device on proxy has impedance error': bits[24],
        'Device on proxy had impedance error': bits[25],
        'Proxy has over-current fault on 3V3 supply line': bits[26],
        'Proxy had over-current fault on 3V3 supply line': bits[27],
        'Device sensor (PD) out of range': bits[28],
        'Device sensor (PD) was out of range': bits[29],
        'Device I2C communication error': bits[30],
        'Device had I2C communication error': bits[31]
    }

    return error_result
