# Kummenberg Internal Definitions
from optoKummenberg.tools.definitions import *

# MRE2 Specific Definitions
MRE2_CHANNEL_CNT = 2

# MRE3 Specific Definitions
MRE3_PHOTO_DIODES_CNT = 4


class OperationMode(IntEnum):
    CURRENT = 0
    OF_CONTROL = 1
    XY_CONTROL = 2
    OF_A_CONTROL = 3
    OF_B_CONTROL = 4
    X_CONTROL = 5
    Y_CONTROL = 6

class LoggerTriggerMode (IntEnum):
    LOGGER_NON_TRIGGERED = 0
    LOGGER_TRIGGER_EQUAL = 1
    LOGGER_TRIGGER_RISING = 2
    LOGGER_TRIGGER_FALLING = 3

class LoggerTriggerFormat (IntEnum):
    LOGGER_TRIGGER_UINT32 = 0
    LOGGER_TRIGGER_INT32 = 1
    LOGGER_TRIGGER_FLOAT = 2

class LoggerRunState (IntEnum):
    LOGGER_STOPPED 		= 0
    LOGGER_RUN 			= 1
    LOGGER_WAITING		= 2
    LOGGER_FINISHED		= 3
