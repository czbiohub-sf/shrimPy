from .mre2 import MRE2Board as connectmre2
from .mre3 import MRE3Board as connectmre3
from .tools.definitions import *

__version__ = '1.3.5434'
__git_version__ = '833a919d3326e110f1503bcd6bd5f96405b3cde3'
